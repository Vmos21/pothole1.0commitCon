---
name: RoadSense Civic Interface
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '500'
    lineHeight: 1.5rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0.015em
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.025em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system serves municipal residents, public works field crews, and city managers. It balances civic transparency, calm authority, and frictionless usability. The emotional tone avoids bureaucratic dryness in favor of welcoming civic partnership, clarity, and rapid issue resolution.

The visual style blends **Modern Corporate Clarity** with **Humanist Civic Softness**:
- Pristine, high-legibility surfaces over calm cool-slate foundations.
- Generous touch targets and rounded contours that reduce intimidation for non-technical residents.
- Clear structural signposting, high contrast ratios exceeding WCAG 2.1 AAA for vital elements, and unambiguous operational status cues.

## Colors

The palette establishes an open, community-oriented experience anchored in clarity and environmental stewardship:

- **Primary (`#2563EB`)**: Civic Blue. Used for core interactive points, primary buttons, focal highlights, and active portal states. Provides an authoritative yet friendly identity.
- **Secondary (`#10B981`)**: Eco/Progress Emerald. Represents resolved municipal tickets, eco-initiatives, safe road metrics, and affirmative states.
- **Tertiary (`#F59E0B`)**: Civic Amber. Reserved for ongoing road repairs, scheduled alerts, and pending municipal actions.
- **Neutral (`#0F172A`)**: Slate 900. High-contrast typography base that ensures supreme readability against light surfaces.

### Surface System
- `surface-base`: `#FFFFFF` (pure white for cards, sheets, and active form components).
- `surface-canvas`: `#F8FAFC` (soft cool slate for global background canvas and page-level scaffolding).
- `surface-subtle`: `#F1F5F9` (neutral containment for inactive chips, input borders, and table rows).
- `surface-border`: `#E2E8F0` (calm, low-friction boundaries ensuring structure without clutter).

## Typography

Inter handles all typographic requirements across the interface, prioritizing legibility and universal device support. 

- Headings use tightened letter spacing (`-0.025em` to `-0.01em`) to provide an intentional, crisp editorial cadence without sacrificing approachability.
- Body sizes default to standard line heights (1.5x) to maintain effortless reading for long civic updates, incident dispatches, and public notes.
- Badges and micro-labels leverage a medium or semi-bold weight (`500` - `600`) with modest letter-spacing expansion (`+0.01em` to `+0.025em`) to ensure instant recognition at a glance.

## Layout & Spacing

The layout operates on an 8pt structural rhythm combined with a responsive fluid-to-contained grid:

- **Desktop (1024px+)**: Max-width container of `1280px`, structured on a 12-column layout with `gutter` of `1.5rem` and outer page margins of `2rem`.
- **Tablet (640px - 1023px)**: 8-column layout with `gutter-sm` of `1rem` and dynamic outer margins scaling down to `1.5rem`.
- **Mobile (<640px)**: 4-column layout with single-column stack fallbacks for forms and incident tracking feeds. Outer page margins lock to `margin-sm` (`1rem`).

Spacing strictly applies to layout distances:
- Use `space-xs` and `space-sm` for dense relationships like icon-to-label offsets and badge padding.
- Use `space-md` for form field grouping, intra-card contents, and list item spacing.
- Use `space-lg` and `space-xl` for card separation, section splits, and primary screen modularity.

## Elevation & Depth

To maintain a clean and trustworthy civic aesthetic, depth is established through **subtle ambient shadows paired with soft boundary strokes**, avoiding harsh silhouettes or distracting drop shadows:

- **Flat/Canvas (Level 0)**: Used for backgrounds (`#F8FAFC`). Pure flush containment without shadow.
- **Card/Resting (Level 1)**: Base cards and standard containers sit on `#FFFFFF` with a crisp `1px` border in `#E2E8F0` and an ambient shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`.
- **Interactive/Hover (Level 2)**: Actionable cards, search bars, and dropdown menus elevate slightly on hover: `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Modal/Drawer (Level 3)**: Citizen report dialogs, mobile navigation panels, and interactive map sheets utilize higher elevation: `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)` over a soft scrim overlay (`rgba(15, 23, 42, 0.40)`).

## Shapes

The design system incorporates generous, approachable geometry to eliminate visual tension:

- Standard controls, chips, and small cards use `0.5rem` to `1rem` (`rounded-md` to `rounded-lg`).
- Primary content panels, modular report cards, and modal sheets scale to `1rem` (`rounded-lg`) and `1.5rem` (`rounded-xl`).
- Status pills, avatars, and quick-filter tags use full-radius pill styling (`9999px`) to emphasize clickable touch friendliness.

## Components

### Buttons
- **Primary**: Solid Civic Blue (`#2563EB`) with crisp `#FFFFFF` text. Padding `0.625rem 1.25rem`, border radius `0.75rem` (`rounded-xl`), font weight `600`. Subtle brightness transition on hover (`#1D4ED8`).
- **Secondary / Eco Action**: Background `#ECFDF5`, text `#065F46`, border `1px solid #A7F3D0`. Used for resolution actions and environmentally friendly municipal programs.
- **Subtle / Neutral**: Solid white background `#FFFFFF`, border `1px solid #E2E8F0`, text `#0F172A`.

### Status Badges & Chips
- Status badges feature pill geometry (`rounded-full`), `0.25rem 0.75rem` padding, and a semantic left status indicator dot:
  - *Reported / In Review*: Slate badge (`bg: #F1F5F9`, `text: #475569`, dot `#64748B`).
  - *Work Scheduled*: Amber badge (`bg: #FEF3C7`, `text: #92400E`, dot `#F59E0B`).
  - *Resolved / Completed*: Emerald badge (`bg: #DCFCE7`, `text: #166534`, dot `#10B981`).
- Filter chips sit at `rounded-full`, with `#F1F5F9` background when inactive and `#2563EB` text over `#EFF6FF` background when selected.

### Input Fields & Controls
- Form controls display a minimal `1px` border of `#CBD5E1` against a `#FFFFFF` fill with `0.75rem` padding.
- Focused states trigger a bold `2px` ring in `#2563EB` with an ambient glow (`box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.15)`).
- Checkboxes and radios utilize `#2563EB` when active, sizing to `1.25rem` square/circle dimensions for high tap accuracy on mobile screens.

### Cards & Feed Items
- Report summaries and community bulletins reside in `#FFFFFF` cards framed by a `1px solid #E2E8F0` border and `1rem` corner rounding.
- Internal card padding follows `space-md` (`1rem`) on mobile, expanding to `space-lg` (`1.5rem`) on desktop screens.

### Municipal Report Flow Components
- **Progress Stepper**: Horizontal node line connecting step badges (`01 Location`, `02 Photo/Detail`, `03 Submit`). Active state uses `#2563EB`, completed uses `#10B981`, and upcoming steps use `#E2E8F0`.
- **Geotag Map Card**: Embedded preview element with an integrated pin icon, displaying neighborhood name, street grid coordinates, and cross-streets with high-contrast text.