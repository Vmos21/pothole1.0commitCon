---
name: Civic Infrastructure & Public Trust
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#001d31'
  on-tertiary-container: '#188ace'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a balance of institutional authority, operational utility, and transparent civic service. It serves two distinct personas under a unified visual language:
1. **Public Citizens**: Seeking frictionless reporting, clear validation, and visible municipal responsiveness.
2. **Municipal Engineers & Operations Directors**: Requiring high-density telemetry, spatial triage, predictive maintenance alerts, and audit trails.

The design movement combines **Corporate Modernism** with **Civic Utility Engineering**. It utilizes high-contrast informational structures, purposeful safety signifiers, clean card boundaries, and zero frivolous ornamentation. The atmosphere evokes the precision of high-reliability public operations: calm, resolute, accountable, and permanently operational.

## Colors

The palette grounds the interface in deep civic foundations while drawing upon universal DOT/transportation safety standards for operational clarity:

- **Primary Canvas & Structural Blueprints (`#0F172A` / `#1E293B`)**: Represents municipal governance, authoritative data tables, main actions, and high-density map interface chrome.
- **Safety Amber / Active Caution (`#F59E0B` / `#EA580C`)**: Reserved exclusively for dynamic alerts, in-progress hazards, warning indicators, and priority dispatch.
- **Operational Status Palette**:
  - *Critical Hazard*: Deep Rose/Red (`#E11D48` text, `#FFE4E6` background, `#FDA4AF` border).
  - *High Priority*: Vivid Road Orange (`#EA580C` text, `#FFEDD5` background, `#FDBA74` border).
  - *Medium Caution*: Signal Amber (`#D97706` text, `#FEF3C7` background, `#FCD34D` border).
  - *Low / Triage*: Municipal Slate (`#475569` text, `#F1F5F9` background, `#CBD5E1` border).
  - *Resolved / Validated*: Emerald Infrastructure (`#059669` text, `#D1FAE5` background, `#6EE7B7` border).
- **Surface & Road Neutrals**:
  - App Canvas Ground: `#F8FAFC`
  - Elevated Card Surface: `#FFFFFF`
  - Subtle Frame Borders: `#E2E8F0`
  - Secondary Demarcation / Inactive Text: `#64748B`

Color is never applied purely decoratively; all saturated hues denote distinct condition levels or active user flows.

## Typography

The typographical pairing splits display approachability from tabular density:
- **Plus Jakarta Sans** delivers a clean, modern civic posture for main headers, citizen reporting titles, and high-level summaries without feeling bureaucratic or cold.
- **Inter** handles all dense operational data, field forms, telemetry readout metrics, status cards, and audit logs. Its robust optical tracking and open letterforms guarantee legibility across rugged mobile field units and split-screen municipal monitoring workstations.

For numerical readouts (work orders, route coordinates, fleet IDs, priority scores), tabular figures (`tnum`) must be enforced globally to preserve spatial alignment across live updating telemetry boards.

## Layout & Spacing

The design system operates on an 8pt base grid with an intentional bifurcation between user modes:

- **Desktop Operations Console (Authority View)**: 12-column fluid grid system with `1.5rem` (`24px`) gutters and persistent collapsible side rail navigation. The dashboard emphasizes simultaneous spatial context (full-height vector maps) paired with high-density side drawers for work order dispatch.
- **Mobile Field & Citizen View**: Single-column structured stream constrained to a max-width container of `480px` on tablets/desktops, utilizing `1rem` margins for edge-to-edge tap safety on handheld devices.
- **Form Layout**: Explicit two-column data pairing on desktop that cleanly collapses into a sequential vertical stack on mobile to prevent inspection misentries in field environments.

## Elevation & Depth

Visual hierarchy uses a hybrid strategy of **Low-Contrast Outlines** paired with **Tonal Tinted Elevation**:

- **Ground Level (Canvas)**: Backgrounds sit at `#F8FAFC` to minimize ocular fatigue during extended shifts.
- **Level 1 (Cards, Work Orders, Panels)**: Pure `#FFFFFF` surface bordered by a crisp `1px solid #E2E8F0` hairline boundary. Ambient shadow: `0 1px 3px rgba(15, 23, 42, 0.04), 0 1px 2px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Active Modals, Flying Incident Inspections, Menus)**: `#FFFFFF` surface with an assertive boundary `1px solid #CBD5E1` and diffused atmospheric depth: `0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.03)`.
- **Level 3 (Emergency Hazard Drawer / Critical Dispatch Overlay)**: `#FFFFFF` surface accompanied by a tinted 40% opacity navy backdrop veil (`#0F172A` at 0.40 alpha).

Elevated elements never float without their enclosing boundary stroke; clear structural definition ensures reliability in variable outdoor lighting conditions.

## Shapes

The roundedness language utilizes precise, disciplined geometry:
- Standard UI cards, input panels, and table modules strictly employ `0.5rem` (`8px`) corner radiuses to reinforce architectural stability.
- Nested containers (e.g., photo inspection thumbnails, inline telemetry stat blocks) step down to `0.25rem` (`4px`) to preserve harmonious visual concentricity.
- Status chips, incident level badges, and interactive pill-toggles employ fully rounded borders (`9999px`) to create an immediate morphological distinction between operational containers (rectangular) and categorical indicators (pill-form).

## Components

### Buttons
- **Primary Operational Action**: Background `#0F172A`, text `#FFFFFF`, border `1px solid transparent`, corner radius `0.5rem`, font weight `600`. Hover state transitions to `#1E293B`.
- **Cautionary / Emergency Action**: Background `#EA580C`, text `#FFFFFF`, hover `#C2410C`.
- **Secondary Civic Action**: Background `#FFFFFF`, text `#0F172A`, border `1px solid #CBD5E1`. Hover state `#F1F5F9`.
- **Destructive Action**: Background `#FFFFFF`, text `#E11D48`, border `1px solid #FDA4AF`. Hover state `#FFE4E6`.

### Badges & Status Chips
Badges use pill geometry (`9999px`), `0.25rem` vertical by `0.625rem` horizontal padding, with `label-sm` uppercase text:
- **Critical**: Background `#FFE4E6`, border `1px solid #FDA4AF`, text `#9F1239`. Prefix with solid red circular dot (`6px`).
- **High**: Background `#FFEDD5`, border `1px solid #FDBA74`, text `#9A3412`. Prefix with orange pulse dot.
- **Medium**: Background `#FEF3C7`, border `1px solid #FCD34D`, text `#92400E`.
- **Low**: Background `#F1F5F9`, border `1px solid #CBD5E1`, text `#475569`.
- **Fixed / Verified**: Background `#D1FAE5`, border `1px solid #6EE7B7`, text `#065F46`. Prefix with check icon.

### Form Inputs & Select Fields
- Containers feature a height of `40px` (desktop) or `48px` (mobile field view) with a background of `#FFFFFF`, border `1px solid #CBD5E1`, and corner radius `0.5rem`.
- Focus state applies a crisp dual ring: `1px solid #0284C7` with an outer halo of `3px rgba(2, 132, 199, 0.15)`.
- Input labels use `title-sm` in `#1E293B` positioned strictly above fields with `0.375rem` spacing; placeholder text sits at `#94A3B8`.

### Checkboxes & Radio Controls
- Base control dimensions are `18px × 18px` with a `1.5px solid #94A3B8` boundary on `#FFFFFF`.
- Checked status triggers a `#0F172A` background fill with a crisp white metric check icon, or a centered `#0F172A` dot for radio elements.

### Cards
- Surface `#FFFFFF`, border `1px solid #E2E8F0`, corner radius `0.5rem`.
- **Citizen Card Pattern**: Generous internal padding (`1.5rem`), prominent headline, single clear status badge, and an expanded step-by-step resolution timeline.
- **Authority Card Pattern**: Compact internal padding (`1rem`), integrated geospatial coordinates, AI confidence score badge (e.g., "94% Pothole Severity"), and direct crew assignment dropdown.

### Specialized Civic Infrastructure Components
- **Telemetry Metric Tile**: Displays single KPI figures in `Plus Jakarta Sans` bold, underpinned by a `12px` delta trend badge and mini sparkline.
- **Inspection Splitter**: Side-by-side comparison pane for AI road surface scans featuring a synchronized interactive slider between the raw citizen photo and computer vision edge detection overlay.